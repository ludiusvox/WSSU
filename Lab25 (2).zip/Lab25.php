<html>
<body>
<?php

$username= $_GET["username"];
$filename=$_GET["filename"];

if(empty($username) && (empty($filename)))
{
	echo "The username and filename are empty.<br/>"; 
}
else if (empty($username))
{
	echo "The username name is empty.<br/>"; 
}
else if (empty($filename))
{
	echo "The filename is empty.<br/>"; 
}

else  
 {

if (preg_match('/^[a-z\d]{6,15}$/i', $username)) {
    echo "Username: $username.</br>";
} else {
    echo "Invalid username.</br>";
	}

if (preg_match('/^[\w\-]+\.(txt$)|(doc$)|(docx$)|(xml$)|(pdf$)|(php$)|(zip$)$/i', $filename)){
	echo "Filename: $filename";
} else {
	echo "Invalid filename.";
	}

 }

?>
</html>
</body>


