package aa1;
import java.io.*;
import java.util.StringTokenizer;
public class CIAADemo
{
        public static void main(String[] args) throws IOException{
            int num_schools = 18;
            String[] CIAAData = new String[num_schools];
            String[] school = new String[num_schools];
            int[] enrollment = new int[num_schools];
            String[] division = new String[num_schools];
            int[] prediction = new int[num_schools];
            FileReader freader = new FileReader("Readme.txt");
            BufferedReader inputFile = new BufferedReader(freader);
            // Create an object
            CIAA report = new CIAA();
            // Read the data from the fileen
            
            for (int index = 0; index < num_schools; index ++)
            {
                CIAAData[index] = inputFile.readLine();
            }
            inputFile.close();
            for (int index = 0; index < CIAAData.length; index++)
            {
                StringTokenizer strTokenizer = new StringTokenizer(CIAAData[index]," ");
                {
                    school[index] = strTokenizer.nextToken();
                    enrollment[index] = Integer.parseInt(strTokenizer.nextToken());
                    division[index] = strTokenizer.nextToken();
                    prediction[index] = Integer.parseInt(strTokenizer.nextToken());
                }
            }
            /* 
             * 
             */
            System.out.println("Schools");
            for(int index = 0; index < school.length; index++)
            {
                    System.out.println(school[index] + " " + enrollment[index] + " "
                    + prediction[index] + " " + division[index]);
                        System.out.println();}
                    }
                    
                    }
                        
                        
            
