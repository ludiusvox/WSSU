package simpleInput;


import edu.cmu.ri.createlab.terk.robot.finch.Finch;
import java.util.Scanner;


/**
 * Write a description of class ColorChangeDemo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ColorChangeDemo
{
   public static void main(String [] args)
   {
  Finch myFinch = new Finch();
  
  int x = 0;
  
  int Red;
  int Blue;
  int Green;
         myFinch.setLED(0, 255, 0);
          myFinch.setWheelVelocities(255,255,1000);
      // Set LED yellow and turn for a half second
          myFinch.setLED(255, 255, 0);
         myFinch.setWheelVelocities(-180,180,500);
      // Set LED Red and back up for a second
         myFinch.setLED(255, 0, 0);
          myFinch.setWheelVelocities(-255,-255,1000);
      // Set LED magenta and turn for a half second
         
  
  while(x < 50 ) {
    	  if(myFinch.isFinchUpsideDown()) {
    		  
    		  myFinch.setLED(0,255,0);
    		  myFinch.sleep(3000);
    		  x++;
    	  }
    	  if(myFinch.isLeftWingDown()) {
    		 
    		  myFinch.setLED(255,0,0);
    		  myFinch.sleep(3000);
    		  x++;
    	  }
    	  if(myFinch.isRightWingDown()) {
    		  
    		  myFinch.setLED(0,0,255);
    		  myFinch.sleep(3000);
    		  x++;
    	  }
    	  if(myFinch.isFinchLevel()) {
    		  
    		  myFinch.setLED(120,75,100);
    		  myFinch.sleep(3000);
    		  x++;
    	  }
    	  if(myFinch.isBeakUp()) {
    		  
    		  myFinch.setLED(200,160,100);
    		  myFinch.sleep(3000);
    		  x++;
    	  }
    	  if(myFinch.isBeakDown()) {
    		  
    		  myFinch.setLED(40,200,60);
    		  myFinch.sleep(3000);
    		  x++;
    	  }
    	  
    	  
      }
  
}
}
