package simpleInput;
public class __SHELL16 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
simpleInput.ColorChangeDemo.main(__bluej_param0);

}}
