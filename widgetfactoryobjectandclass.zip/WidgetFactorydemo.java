import java.util.Scanner;
/**
 * Write a description of class WidgetFactory here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class WidgetFactorydemo
{
 
    public static void main(String[] args) 
    {
        Scanner imput= new Scanner(System.in);
        double totalwidget;
        double total;
        double rate;
        double dailytotal;
        double dailyhour;
        System.out.println("What is the total amount of widgets?");
        totalwidget = imput.nextDouble();
        
        widgetfactory widget = new widgetfactory(totalwidget); 
        {
        
        rate = 10;
        dailyhour = 16;
        dailytotal = 16 * 10; 
        total = totalwidget / dailytotal;
    }
        System.out.println("The total amount of widgets is" + totalwidget);
 
        System.out.println("The total number of widgets after calculations is is ---?" 
        + total);
        System.out.println("The daily total of widgets complete" + dailytotal);
        System.out.println("The daily total of widgets complete  " + total + "  days");
    }
 
}



