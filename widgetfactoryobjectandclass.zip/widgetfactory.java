
/**
 * Write a description of class Widget here.
 * 
 * @author (Aaron Linder) 
 * @version 1.0 (10/07/2013)
 */

   public class widgetfactory
   {
   
    private double TOTALWIDGET;  // total amount of widgets produced
    public int rate;   // the rate of widgets per hour (predivide
    public double dailyhour;  //days in hours (the problem says two shifts of 8 hours a day)
    public double dailytotal;
    private double total;
    // The constructor method: initialize the rate
    public widgetfactory(double tw) 
    { 
        TOTALWIDGET = tw;
        rate = 10;
        dailyhour = 16;
        dailytotal = 16 * 10; 
        total = tw * dailytotal;
    }   
// The instance methods: compute values based on the daily values

    public double setTotalWidget() 
    { 
        return TOTALWIDGET; 
    }
    public double gettotal()
    {
        return total;
}
  public int getrate()
  {
      return rate;
    }
public double getdailyhour()
{
return dailyhour;
}
public double getTOTALWIDGET()
{
return TOTALWIDGET;
}
}